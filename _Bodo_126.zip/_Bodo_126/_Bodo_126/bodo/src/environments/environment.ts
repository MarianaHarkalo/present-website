// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyBHjWq2Hq14DYjMxSpk-v8OQep6LMRfiNE",
    authDomain: "bodo-83e2f.firebaseapp.com",
    databaseURL: "https://bodo-83e2f.firebaseio.com",
    projectId: "bodo-83e2f",
    storageBucket: "bodo-83e2f.appspot.com",
    messagingSenderId: "65785787344",
    appId: "1:65785787344:web:bec80d3705661b3dad3fd5",
    measurementId: "G-NSNXPBQ8N9"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
