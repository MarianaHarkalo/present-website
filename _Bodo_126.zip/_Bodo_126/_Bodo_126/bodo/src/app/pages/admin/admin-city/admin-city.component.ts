import { Component, OnInit } from '@angular/core';
import { ICity } from 'src/app/shared/interfaces/city.interface';
import { CityService } from 'src/app/shared/services/city.service';
import { City } from 'src/app/shared/models/city.model';
import { ICategory } from 'src/app/shared/interfaces/category.interface';
import { CategoriesService } from 'src/app/shared/services/categories.service';
import { Category } from 'src/app/shared/models/category.model';

@Component({
  selector: 'app-admin-city',
  templateUrl: './admin-city.component.html',
  styleUrls: ['./admin-city.component.scss']
})
export class AdminCityComponent implements OnInit {
  categoryID: number = 1;
  name: string;
  editStatus: boolean;
  adminCity: Array<ICity> = [];
  city={
    name:''
  }
  constructor(private catService: CityService) { }

  ngOnInit(): void {
    this.getCategory();
  }

  private getCategory(): void {
    this.catService.getCategory().subscribe(
      data => {
        this.adminCity = data;
      }
    );
  }

  public addCategory(): void {
    const city: ICity = new City(1, this.city.name);
    if (!this.editStatus) {
      if (this.adminCity.length > 0) {
        city.id = this.adminCity.slice(-1)[0].id + 1;
      }
      this.catService.addCategory(city).subscribe(
        () => {
          this.getCategory();
        }
      );
    }
    else {
      city.id = this.categoryID;
      this.catService.updateCategory(city).subscribe(() => {
        this.getCategory();
      });
  
      this.editStatus = false;
    }
    this.city.name="";
  }

  public deleteCategory(category: ICity): void {
    this.catService.deleteCategory(category).subscribe(
      () => {
        this.getCategory();
      }
    );
  }
  public editCategory(city: ICity) {
    this.categoryID=city.id;
    this.city.name=city.city;
    this.editStatus = true;
  }
}
