import { Component, OnInit } from '@angular/core';
import { FedbackService } from 'src/app/shared/services/fedback.service';
import { IFedback } from 'src/app/shared/interfaces/fedback.interface';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable } from 'rxjs';
import { CatalogService } from 'src/app/shared/services/catalog.service';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { Fedback } from 'src/app/shared/models/fedback.model';

@Component({
  selector: 'app-admin-fedback',
  templateUrl: './admin-fedback.component.html',
  styleUrls: ['./admin-fedback.component.scss']
})
export class AdminFedbackComponent implements OnInit {
  fedID:number=1;
  catID:number=1;
  adminFed:Array <IFedback>=[];
  catalog: Array<ICatalog> = [];
  catalogName:string;
  name:string;
  email:string;
  image:string="assets/images/camera.jpg";
  fedback:string;
  productCatalog:ICatalog;
  editStatus:boolean;
  uploadProgress: Observable<number>;

  constructor(private fedService: FedbackService,
    private afStorage: AngularFireStorage,
    private catService: CatalogService,) { }

  ngOnInit(): void {
    this.getFedback();
    this.getCatalog();
  }
  private getFedback(): void {
    this.fedService.getFedback().subscribe(
      data => {
        this.adminFed = data;
      }
    );
  }
  private getCatalog(): void {
    this.catService.getCatalog().subscribe(
      data => {
        this.catalog = data;
      }
    );
  }
  setCatalog(): void {
    const index = this.catalog.findIndex(elem => elem.name.toLocaleLowerCase() === this.catalogName.toLocaleLowerCase());
    this.productCatalog= this.catalog[index];
    console.log(this.productCatalog);
  }
  public deleteFedback(fedback: IFedback): void {
    this.fedService.deleteFedback(fedback).subscribe(
      () => {
        this.getFedback();
      }
    );
  }
  public editFedback(fedback: IFedback) {
    this.fedID = fedback.id;
    this.fedb.email=fedback.email;
    this.image=fedback.image;
    this.fedb.name=fedback.name;
    this.fedb.catalogName=fedback.catalog;
    this.fedb.fedback=fedback.fedback;
    this.editStatus = true;
  }
  fedb={
    catalogName:'',
    name:'',
    email:'',
    fedback:'',
  }
  public addFedback(): void {
    const index = this.catalog.findIndex(elem => elem.name.toLocaleLowerCase() === this.fedb.catalogName.toLocaleLowerCase());
    this.productCatalog= this.catalog[index];
    console.log(this.productCatalog);
    const fedback: IFedback = new Fedback(1,this.fedb.catalogName, this?.fedb.name, this?.fedb.email, this?.fedb.fedback, this?.image, new Date(),this?.productCatalog.id);   
    if (!this.editStatus) {
      if (this.adminFed.length > 0) {
        fedback.id = this.adminFed.slice(-1)[0].id + 1;
      }
      this.fedService.addFedback(fedback).subscribe(
        () => {
          this.getFedback();
        }
      );
    }
    else {
      fedback.id = this.fedID;
      this.fedService.updateFedback(fedback).subscribe(() => {
        this.getFedback();
      });
      this.editStatus = false;
    } 
    this.fedb.catalogName="";
    this.fedb.name="";
    this.fedb.email="";
    this.fedb.fedback="";
    this.image="assets/images/camera.jpg";
  }  
  uploadFile(event) {
    const file = event.target.files[0];
    const filePath = `images/${this.uuid()}.${file.type.split('/')[1]}`;
    const task = this.afStorage.upload(filePath, file);
    this.uploadProgress = task.percentageChanges();
    task.then(e => {
      this.afStorage.ref(`images/${e.metadata.name}`).getDownloadURL().subscribe(url => {
        this.image = url;
      });
    });

  }
  uuid(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      let r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
