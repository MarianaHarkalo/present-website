import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal/public_api';
import { EmailValidator } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  admin={
    email:'',
    password:''
  }
  authorization:boolean;
  constructor() { }
  @ViewChild('smModal') public smModal: ModalDirective;
  ngOnInit(): void {
  }
  ngAfterContentInit(): void {

  }

}
