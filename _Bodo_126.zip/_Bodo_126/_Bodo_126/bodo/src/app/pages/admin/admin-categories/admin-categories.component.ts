import { Component, OnInit } from '@angular/core';
import { ICategory } from 'src/app/shared/interfaces/category.interface';
import { CategoriesService } from 'src/app/shared/services/categories.service';
import { Category } from 'src/app/shared/models/category.model';

@Component({
  selector: 'app-admin-categories',
  templateUrl: './admin-categories.component.html',
  styleUrls: ['./admin-categories.component.scss']
})
export class AdminCategoriesComponent implements OnInit {
  categoryID:number= 1;
  name: string;
  editStatus: boolean;
 
  adminCategory: Array<ICategory> = [];
  category={
    name:''
  }
  constructor(private catService: CategoriesService) { }

  ngOnInit(): void {
    this.getCategory();
  }

  private getCategory(): void {
    this.catService.getCategory().subscribe(
      data => {
        this.adminCategory = data;
      }
    );
  }

  public addCategory(): void {
    const category: ICategory = new Category(1, this.category.name);
    if (!this.editStatus) {
    if (this.adminCategory.length > 0) {
      category.id = this.adminCategory.slice(-1)[0].id + 1;
    }
    this.catService.addCategory(category).subscribe(
      () => {
        this.getCategory();
      }
    );
    }
    else {
      category.id = this.categoryID;
      this.catService.updateCategory(category).subscribe(() => {
        this.getCategory();
      });
      this.editStatus = false;
    }
    this.categoryID = null;
    this.category.name ="";
  }

  public deleteCategory(category: ICategory): void {
    this.catService.deleteCategory(category).subscribe(
      () => {
        this.getCategory();
      }
    );
  }

  public editCategory(category: ICategory) {
    this.categoryID = category.id;
    this.category.name = category.name;
    this.editStatus = true;
  }
}
