import { Component, OnInit } from '@angular/core';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { CatalogService } from 'src/app/shared/services/catalog.service';
import { Catalog } from 'src/app/shared/models/catalog.model';
import { CategoriesService } from 'src/app/shared/services/categories.service';
import { ICategory } from 'src/app/shared/interfaces/category.interface';

import { AngularFireStorage } from '@angular/fire/storage';
import 'firebase/storage';
import { Observable } from 'rxjs';
import { ICity } from 'src/app/shared/interfaces/city.interface';
import { CityService } from 'src/app/shared/services/city.service';
@Component({
  selector: 'app-admin-catalog',
  templateUrl: './admin-catalog.component.html',
  styleUrls: ['./admin-catalog.component.scss']
})
export class AdminCatalogComponent implements OnInit {
  adminCategory: Array<ICategory> = [];
  adminCity: Array<ICity> = [];
  categoryName: string;
  catalogName: string;
  catalogPrice: number;
  catalogShortDescription: string;
  catalogTime: string;
  catalogCountPerson: number;
  catalogUrl: string;
  catalogHowHappen: string;
  catalogWhySelect: string;
  catalogAdress: string;
  productCategory: ICategory;
  productCity: ICity;
  catalogMap: string;
  categoryID: number;
  cl: number = 1;
  catalogID: number = 1;
  nameUA: string;
  nameEN: string;
  editStatus: boolean;
  adminCatalog: Array<ICatalog> = [];
  producImage: Array<string> = [];
  productImage: string;
  productVideo: string;
  categorySize: string;
  categoryCity: string;
  status: boolean = true;
  uploadProgress: Observable<number>;
  subscription: any;
  constructor(private catService: CatalogService,
    private categService: CategoriesService,
    private cityService:CityService,
    private afStorage: AngularFireStorage) { }

  ngOnInit(): void {
    this.getCatalog();
    this.getCategory();
    this.getCity();
  }
  private getCategory(): void {
    this.categService.getCategory().subscribe(
      data => {
        this.adminCategory = data;
      }
    );
  }

  setCategory(): void {
    const index = this.adminCategory.findIndex(elem => elem.name.toLocaleLowerCase() === this.categoryName.toLocaleLowerCase());
    this.productCategory = this.adminCategory[index];
    console.log(this.productCategory);
  }
  private getCity(): void {
    this.cityService.getCategory().subscribe(
      data => {
        this.adminCity = data;
      }
    );
  }

  setCity(): void {
    const index = this.adminCity.findIndex(elem => elem.city.toLocaleLowerCase() === this.categoryCity.toLocaleLowerCase());
    this.productCity = this.adminCity[index];
    console.log(this.productCity);
  }
  private getCatalog(): void {
    this.catService.getCatalog().subscribe(
      data => {
        this.adminCatalog = data;
      }
    );
  }

  public addCatalog(): void {
    const catalog: ICatalog = new Catalog(1,1, this.catalogName, this.catalogShortDescription, this?.catalogPrice, this?.catalogTime, this?.catalogCountPerson, this?.productCategory.name, this?.catalogHowHappen, this?.catalogWhySelect, this?.catalogUrl, this?.catalogAdress, this?.producImage, this?.categorySize, this?.categoryCity, this?.catalogMap);
    if (!this.editStatus) {
      if (this.adminCatalog.length > 0) {
        catalog.id = this.adminCatalog.slice(-1)[0].id + 1;
      }
      this.catService.addCatalog(catalog).subscribe(
        () => {
          this.getCatalog();
        }
      );
    }
    else {
      catalog.id = this.catalogID;
      this.catService.updateCatalog(catalog).subscribe(() => {
        this.getCatalog();
      });
      this.editStatus = false;
    }
    this.catalogName = "";
    this.catalogShortDescription = "";
    this.catalogTime = "";
    this.catalogUrl = "";
    this.catalogWhySelect = "";
    this.catalogHowHappen = "";
    this.catalogCountPerson = null;
    this.catalogPrice = null;
    this.catalogAdress = "";
    this.categoryCity = "";
    this.producImage = [];
    this.productVideo = "";
    this.catalogMap="";
    this.uploadProgress=null;
  }

  public deleteCatalog(catalog: ICatalog): void {
    this.catService.deleteCatalog(catalog).subscribe(
      () => {
        this.getCatalog();
      }
    );
  }

  public editCatalog(catalog: ICatalog) {
    this.catalogID = catalog.id;
    this.catalogName = catalog.name;
    this.catalogShortDescription = catalog.shortDescription;
    this.catalogTime = catalog.time;
    this.catalogUrl = catalog.url;
    this.catalogWhySelect = catalog.whySelect;
    this.catalogHowHappen = catalog.howHappen;
    this.catalogCountPerson = catalog.countPerson;
    this.catalogPrice = catalog.price
    this.catalogAdress = catalog.adress;
    this.productCategory.name = catalog.category;
    this.categorySize=catalog.size;
    this.catalogMap=catalog.map;
    this.producImage=catalog.images;
    this.categoryCity=catalog.city;
    this.editStatus = true;
  }

  uploadFile(event) {
    const file = event.target.files[0];
    const filePath = `images/${this.uuid()}.${file.type.split('/')[1]}`;
    const task = this.afStorage.upload(filePath, file);
    this.uploadProgress = task.percentageChanges();
    task.then(e => {
      this.afStorage.ref(`images/${e.metadata.name}`).getDownloadURL().subscribe(url => {
        this.productImage = url;
        this.producImage.push(this.productImage);
      });
    });

  }
  uploadFileVideo(event) {
    const file = event.target.files[0];
    const filePath = `video/${this.uuid()}.${file.type.split('/')[1]}`;
    const task = this.afStorage.upload(filePath, file);
    this.uploadProgress = task.percentageChanges();
    task.then(e => {
      this.afStorage.ref(`video/${e.metadata.name}`).getDownloadURL().subscribe(url => {
        this.productVideo = url;

      });
    });

  }

  uuid(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      let r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

}
