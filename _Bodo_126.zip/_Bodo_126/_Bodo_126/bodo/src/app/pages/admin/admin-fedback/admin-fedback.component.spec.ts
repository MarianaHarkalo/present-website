import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminFedbackComponent } from './admin-fedback.component';

describe('AdminFedbackComponent', () => {
  let component: AdminFedbackComponent;
  let fixture: ComponentFixture<AdminFedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminFedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminFedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
