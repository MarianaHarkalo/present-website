import { Component, OnInit } from '@angular/core';
import { OrdersService } from 'src/app/shared/services/orders.service';
import { IOrder } from 'src/app/shared/interfaces/order.interface';

@Component({
  selector: 'app-admin-order',
  templateUrl: './admin-order.component.html',
  styleUrls: ['./admin-order.component.scss']
})
export class AdminOrderComponent implements OnInit {
  orders: Array<IOrder> = [];
  constructor(private orderService: OrdersService) { }

  ngOnInit(): void {
    this.getOrders()
  }
  private getOrders(){
    this.orderService.getOrder().subscribe(
      data => {
        this.orders = data;
      }
    )
  }
  public deleteOrder(order: IOrder): void {
    this.orderService.deleteOrder(order).subscribe(
      () => {
        this.getOrders();
      }
    );
  }
}
