import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/services/auth.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  signStatus: boolean;
  public signUpForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.pattern('admin@gmail.com')]),
    password: new FormControl('', [Validators.required, Validators.pattern('')])
  });
  public loginForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.pattern('admin@gmail.com')]),
    password: new FormControl('', [Validators.required, Validators.pattern('123456')])
  });

  constructor(private auth: AuthService) { }

  ngOnInit(): void {
  }

  public signUp(formData: FormData) {
    console.log(formData);
   }

  public login(formData: FormData) {
    console.log(formData);
    this.auth.login(formData['email'], formData['password']);
  }
  
  public btnStatus(): void {
    console.log("jjjj");
    
    this.signStatus = !this.signStatus;
  }


}
