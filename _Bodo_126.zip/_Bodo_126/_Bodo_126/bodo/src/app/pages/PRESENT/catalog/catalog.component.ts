import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { CatalogService } from 'src/app/shared/services/catalog.service';
import { ActivatedRoute, Router,Event, NavigationEnd } from '@angular/router';
import { CategoriesService } from 'src/app/shared/services/categories.service';
import { Catalog } from 'src/app/shared/models/catalog.model';
import { OrdersService } from 'src/app/shared/services/orders.service';
import { ICategory } from 'src/app/shared/interfaces/category.interface';
import {FormControl} from '@angular/forms';
import { config } from 'rxjs';
import { MatPaginator } from '@angular/material/paginator';

import { HttpClient } from '@angular/common/http';
import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { CityService } from 'src/app/shared/services/city.service';
import { ICity } from 'src/app/shared/interfaces/city.interface';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.scss']
})
export class CatalogComponent implements OnInit {
  adminCategory: Array<ICategory> = [];
  arrCatalog: Array<ICatalog> = [];
  arrCity: Array<ICity> = [];
  id: number;
  productCategory: ICategory;
  categorName: string="";
  selectedValue:string;
  private sub: any;
  toppings = new FormControl();
  sort:string="";
  City:string="";
  k:string='asc'
  stat:boolean=true;
  p: number = 1;
  count: number = 11;
  page = 4;
  
  constructor(private orderService: OrdersService, private prodService: CatalogService,catService:CategoriesService,
    private activateRoute: ActivatedRoute,
               private router: Router,
               private cityService:CityService){
                  this.router.events.subscribe((event: Event) => {
                if (event instanceof NavigationEnd) {
                  const categoryName = this.activateRoute.snapshot.paramMap.get('category');
                  this.getProducts(categoryName);
                }
              }
              );
            }
  ngOnInit(): void {
    this.getProducts();
    this.getCity();
  }
  scroll(el: HTMLElement) {
    el.scrollIntoView({ behavior: 'smooth' });
  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  setPage(index: number) {
    this.paginator.pageIndex = index;
  }
  @HostListener('window:scroll', ['$event'])
  mmm(k):void{
    if(k==='asc'){
      k='desc';
    }
    else{
      k="asc"
    }
    console.log(this.sort);
    
  }
  setCategory(): void {
    const index = this.adminCategory.findIndex(elem => elem.name.toLocaleLowerCase() === this.categorName.toLocaleLowerCase());
    this.productCategory = this.adminCategory[index];
    console.log(this.productCategory);
  }

  private getProducts(categoryName?: string): void {
   this.prodService.getCatalog().subscribe(
      data => {
        this.arrCatalog = data;
      }
    )
  }
  private getCity(): void {
    this.cityService.getCategory().subscribe(
      data => {
        this.arrCity = data;
      }
    )
  }
  slideConfig = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 3000,
    speed: 1500,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  };
  addBasket(product: ICatalog): void {
    let localProducts: Array<ICatalog> = [];
    if (localStorage.length > 0 && localStorage.getItem('catalog')) {
      localProducts = JSON.parse(localStorage.getItem('catalog'));
      if (localProducts.some(prod => prod.name === product.name)) {
        const index = localProducts.findIndex(prod => prod.name === product.name);
        localProducts[index].count += product.count;
      }
      else{
        localProducts.push(product);
      }
      localStorage.setItem('catalog', JSON.stringify(localProducts));
    } else {
      localProducts.push(product);
      localStorage.setItem('catalog', JSON.stringify(localProducts));
    }
    this.orderService.basket.next(localProducts);
  }
  catCount(product: ICatalog, status: boolean) {
    if (status) {
      product.count++;
    } else {
      if (product.count > 1) {
        product.count--;
      }
    }
  }

}
