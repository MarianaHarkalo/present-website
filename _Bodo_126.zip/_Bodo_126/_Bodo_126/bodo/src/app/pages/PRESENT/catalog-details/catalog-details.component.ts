import { Component, OnInit, ViewChild, ElementRef, HostListener, TemplateRef, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoriesService } from 'src/app/shared/services/categories.service';
import { CatalogService } from 'src/app/shared/services/catalog.service';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { IFedback } from 'src/app/shared/interfaces/fedback.interface';
import { AngularFireStorage } from '@angular/fire/storage';
import { FedbackService } from 'src/app/shared/services/fedback.service';
import { Fedback } from 'src/app/shared/models/fedback.model';
import { Observable } from 'rxjs';
import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { DomSanitizer } from '@angular/platform-browser';
import { OrdersService } from 'src/app/shared/services/orders.service';

@Component({
  selector: 'app-catalog-details',
  templateUrl: './catalog-details.component.html',
  styleUrls: ['./catalog-details.component.scss']
})
export class CatalogDetailsComponent implements OnInit {
 
  p: number = 1;
  cou: number = 0;
  count: number = 5;
  page = 4;
  status: boolean = true;
  sticky: boolean = false;
  apear: boolean = false;
  elementPosition: any;
  view: ICatalog = null;
  public CatalogId;
  menuPosition: any;
  productCatalog: ICatalog;
  statusPackaging: boolean = true;
  arrFedback: Array<IFedback> ;
  arrCatalog: Array<ICatalog> = [];
  fedbackName: string;
  fedbackEmail: string;
  fedbackText: string;
  productImage: string= "assets/images/camera.jpg";;
  uploadProgress: Observable<number>;
  constructor(private catService: CatalogService,
    private fedService: FedbackService,
    private route: ActivatedRoute,
    private afStorage: AngularFireStorage,
    public sanitizer: DomSanitizer,
    private orderService:OrdersService
  ) { }
  
  @ViewChild('stickyMenu') menuElement: ElementRef;
  @ViewChild('slickModal', { static: true }) slickModal: SlickCarouselComponent;
 
  goto(sc) {
      this.slickModal.slickGoTo(sc);
  }
  Name: string;
  ngAfterViewInit() {
  }
  @HostListener('window:scroll', ['$event'])
  handleScroll() {
    const windowScroll = window.pageYOffset;
    if (windowScroll >= this.elementPosition) {
      this.sticky = true;
    } else {
      this.sticky = false;
    }
  }
  isSticky:boolean=false;
  checkScroll() {
    this.isSticky = window.pageYOffset >= 0;
  }
  ngOnInit(): void {
    this.getMyProduct();
    this.getFedback();
    this.handleScroll();
    this.checkScroll();
    
  }
  filterUser(user: IFedback) {
   this.arrCatalog.filter
  }
  private getFedback(): void {
    this.fedService.getFedback().subscribe(
      data => {
        this.arrFedback = data;
      }
    );
  }
   user = {
    fedbackName: '',
    fedbackEmail: '',
    fedbackText:'',

  };
  public addFedback(): void {
    this.apear = false
    const fedback: IFedback = new Fedback(1,this.view?.name, this?.user.fedbackName, this?.user.fedbackEmail, this?.user.fedbackText, this?.productImage, new Date(),this?.view.id);
    if (this.arrFedback.length > 0) {
      fedback.id = this.arrFedback.slice(-1)[0].id + 1;
    }
    this.fedService.addFedback(fedback).subscribe(
      () => {
        this.getFedback();
      }
    );
    this.arrFedback.push(fedback);
    this.productImage="assets/images/camera.jpg";;
  }
  getMyProduct(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.catService.getOneCatalog(id).subscribe(
      data => {
        this.view = data;
      }
    );
  }
  uploadFile(event) {
    const file = event.target.files[0];
    const filePath = `imagesFedback/${this.uuid()}.${file.type.split('/')[1]}`;
    const task = this.afStorage.upload(filePath, file);
    this.uploadProgress = task.percentageChanges();
    task.then(e => {
      this.afStorage.ref(`imagesFedback/${e.metadata.name}`).getDownloadURL().subscribe(url => {
        this.productImage = url;
      });
    });
  }
  uuid(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      let r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  scroll(el: HTMLElement) {
    el.scrollIntoView({ behavior: 'smooth' });
  }
  addBasket(product: ICatalog): void {
    let localProducts: Array<ICatalog> = [];
    if (localStorage.length > 0 && localStorage.getItem('catalog')) {
      localProducts = JSON.parse(localStorage.getItem('catalog'));
      if (localProducts.some(prod => prod.name === product.name)) {
        const index = localProducts.findIndex(prod => prod.name === product.name);
        localProducts[index].count += product.count;
      }
      else{
        localProducts.push(product);
      }
      localStorage.setItem('catalog', JSON.stringify(localProducts));
    } else {
      localProducts.push(product);
      localStorage.setItem('catalog', JSON.stringify(localProducts));
    }
    this.orderService.basket.next(localProducts);
  }

}

