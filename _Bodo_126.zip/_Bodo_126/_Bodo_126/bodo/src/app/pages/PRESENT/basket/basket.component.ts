import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { OrdersService } from 'src/app/shared/services/orders.service';
import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { IOrder } from 'src/app/shared/interfaces/order.interface';
import { Order } from 'src/app/shared/models/order.model';
import { NgForm } from '@angular/forms';
import { CityService } from 'src/app/shared/services/city.service';
import { ICity } from 'src/app/shared/interfaces/city.interface';

@Component({
  selector: 'app-basket',
  templateUrl: './basket.component.html',
  styleUrls: ['./basket.component.scss']
})
export class BasketComponent implements OnInit {
  basket:Array<IOrder>;
  orders: Array<ICatalog> = [];
  adminCity: Array<ICity> ;
  categoryCity: string;
  productCity: ICity;
  ordersDetails: Array<ICatalog>
  userName: string;
  userPhone: string;
  userCity: string;
  userStreet: string;
  userHouse: string;
  totalPayment: number;
  userComment: string="";
  totalPrice: number;
  userPacking:string;
  checkStatus:boolean=true;
  check:string="Зелено-бежева";
  sticky: boolean = false;

  slideConfig = {
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 3000,
    speed: 1500,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  };
  user = {
    name: '',
    secondName: '',
    number:'',
    email:'',
  
    city:'',  
    adress:'',
  };
  constructor(private orderService: OrdersService,
              private cityService:CityService) { }
 @ViewChild('slickModal', { static: true }) slickModal: SlickCarouselComponent;
  ngOnInit(): void {
    this.getBasket()
    this.getCity()
    this.getBasketOrder()
    
  }
  private getBasket(): void {
    if (localStorage.length > 0 && localStorage.getItem('catalog')) {
      this.orders = JSON.parse(localStorage.getItem('catalog'));
    }
    this.total();
  }
  goto(sc) {
    this.slickModal.slickGoTo(sc);
  }
  private total() {
  
    this.totalPrice = this.orders.reduce((total, elem) => {
     
      return total+ elem.price*elem.count;
     

    }, 0);
  }
  deleteProduct(product: ICatalog) {
    const index = this.orders.findIndex(prod => prod.id === product.id);
    this.orders.splice(index, 1);
    this.total();
    this.updateLocalCatalog();
    this.orderService.basket.next(this.orders);
  }
  
  private updateLocalCatalog(): void {
    localStorage.setItem('catalog', JSON.stringify(this.orders));
  }
  productCount(product: ICatalog, status: boolean) {
    if (status) {
      product.count++;
    } else {
      if (product.count > 1) {
        product.count--;
      }
    }
    this.total();
    this.updateLocalProducts();
    this.orderService.basket.next(this.orders);
  }

  addOrder(): void {
    const newOrder: IOrder = new Order(1, 
      this.user.name,
      this.user.number,
      this.user.city,
      this.check,
      this.orders,
      this.totalPrice,
      this.userComment,
      new Date());
      if (this.basket.length > 0) {
        newOrder.id = this.basket.slice(-1)[0].id + 1;
      }
    this.orders = [];
    localStorage.setItem('catalog', JSON.stringify(this.orders));
    this.orderService.basket.next(this.orders);
    this.orderService.addOrder(newOrder).subscribe(()=>{
      this.getBasket();
    });
  }
  private getBasketOrder(): void {
    this.orderService.getOrder().subscribe(
      data => {
        this.basket = data;
      }
    );
  }

  private updateLocalProducts(): void {
    localStorage.setItem('catalog', JSON.stringify(this.orders));
  }
  addData(name,secondName){
    
  }
  detectChanges(newVal, model, validation): void {
    if (validation.valid) model._valid = true;
    else model._valid = false;
    }
    changeCount(order,orderCount){
      order.count=orderCount.value
      this.total()
    }
    private getCity(): void {
      this.cityService.getCategory().subscribe(
        data => {
          this.adminCity = data;
        }
      );
    }
    @ViewChild('stickyMenu') menuElement: ElementRef;
    setCity(): void {
      const index = this.adminCity.findIndex(elem => elem.city.toLocaleLowerCase() === this.user.city.toLocaleLowerCase());
      this.productCity = this.adminCity[index];
      console.log(this.productCity);
    }
    scroll(el: HTMLElement) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
}
