import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePresentComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomePresentComponent;
  let fixture: ComponentFixture<HomePresentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomePresentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePresentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
