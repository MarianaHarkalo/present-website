import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackPresentsComponent } from './feedback-presents.component';

describe('FeedbackPresentsComponent', () => {
  let component: FeedbackPresentsComponent;
  let fixture: ComponentFixture<FeedbackPresentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackPresentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackPresentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
