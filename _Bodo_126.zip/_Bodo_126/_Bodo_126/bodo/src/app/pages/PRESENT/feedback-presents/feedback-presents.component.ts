import { Component, OnInit } from '@angular/core';
import { FedbackService } from 'src/app/shared/services/fedback.service';
import { Fedback } from 'src/app/shared/models/fedback.model';
import { IFedback } from 'src/app/shared/interfaces/fedback.interface';
import { CatalogService } from 'src/app/shared/services/catalog.service';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
@Component({
  selector: 'app-feedback-presents',
  templateUrl: './feedback-presents.component.html',
  styleUrls: ['./feedback-presents.component.scss']
})
export class FeedbackPresentsComponent implements OnInit {
  arrFedback: Array<IFedback>;
  arrCatalog: Array<ICatalog>;
  view: ICatalog;
  p: number = 1;
  cou: number = 0;
  count: number = 5;
  page = 4;
  constructor(private fedService: FedbackService,private catService: CatalogService,) { }
  ngOnInit(): void {
    console.log(this.arrCatalog,"kkkkk");
    this.getFedback();
    this.getCatalog();
  }
  private getFedback(): void {
    this.fedService.getFedback().subscribe(
      data => {
        this.arrFedback = data;
      }
    );
  }
  getCatalog(): void {
    this.catService.getCatalog().subscribe(
      data => {
        this.arrCatalog = data;
      }
    );
  }
  scroll(el: HTMLElement) {
    el.scrollIntoView({ behavior: 'smooth' });
  }
}
