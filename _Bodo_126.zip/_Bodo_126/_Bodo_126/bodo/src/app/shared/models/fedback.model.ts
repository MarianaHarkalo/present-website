import { ICatalog } from '../interfaces/catalog.interface';
import { IFedback } from '../interfaces/fedback.interface';
export class Fedback implements IFedback {
    constructor(
   public id:number,
   public catalog:string,
   public name?:string,
   public email?:string,
   public fedback?:string,
   public image?:string,
   public date?: Date | string,
   public catid?:number,
    ){}
}