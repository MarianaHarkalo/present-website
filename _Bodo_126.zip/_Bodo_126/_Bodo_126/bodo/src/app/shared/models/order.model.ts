import { IOrder } from '../interfaces/order.interface';
import { ICatalog } from '../interfaces/catalog.interface';

export class Order implements IOrder {
    constructor(
        public id: number,
        public userName: string,
        public userPhone: string,
        public userCity: string,
        public userPacking: string,
        public ordersDetails: Array<ICatalog>,
        public totalPayment: number,
        public userComment?: string,
        public date?: Date | string,
    ) { }
}