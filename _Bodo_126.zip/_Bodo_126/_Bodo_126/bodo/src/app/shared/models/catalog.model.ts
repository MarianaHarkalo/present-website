import { ICatalog } from '../interfaces/catalog.interface';
import { ICategory } from '../interfaces/category.interface';

export class Catalog implements ICatalog {
    constructor(
        public id: number,
        public count: number = 1,
        public name: string,
        public shortDescription: string,
        public price?:number,
        public time?:string,
        public countPerson?:number,
        public category?:string,
        public howHappen?:string,
        public whySelect?:string,
        public url?:string,
        public adress?:string,
        public images?:Array<string>,
        public size?:string,
        public city?:string,
        public map?:string,
    ) {}
}
