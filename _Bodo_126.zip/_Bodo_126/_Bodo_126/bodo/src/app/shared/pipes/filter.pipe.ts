import { Pipe, PipeTransform } from '@angular/core';
import { UpperCasePipe, LowerCasePipe } from '@angular/common';

@Pipe({
  name: 'filter',
 
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], field : string, value): any[] {
    if (!items) return null;
    if (!value || value.length === 0) return items;
    return items.filter(it =>
    it[field] === value);
  }
}

