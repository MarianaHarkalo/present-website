import { SavePipe } from './save.pipe';

describe('SavePipe', () => {
  it('create an instance', () => {
    const pipe = new SavePipe();
    expect(pipe).toBeTruthy();
  });
});
