export interface IFedback{
   id:number;
   catalog:string;
   name?:string;
   email?:string;
   fedback?:string;
   image?:string;
   date?: Date | string,
   catid?:number;
}
