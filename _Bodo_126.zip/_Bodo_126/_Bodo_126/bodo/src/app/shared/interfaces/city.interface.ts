export interface ICity {
    id: number;
    city: string;
    
  
}