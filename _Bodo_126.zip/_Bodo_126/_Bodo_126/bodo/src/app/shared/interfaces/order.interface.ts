import { ICatalog } from './catalog.interface';

export interface IOrder {
    id: number;
    userName: string;
    userPhone: string;
    userCity: string;
    userPacking:string;
    ordersDetails: Array<ICatalog>;
    totalPayment: number;
    userComment?: string;
    date?: Date | string,
}