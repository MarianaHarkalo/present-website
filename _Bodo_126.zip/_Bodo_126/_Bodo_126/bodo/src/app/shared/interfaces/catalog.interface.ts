import { ICategory } from './category.interface';
export interface ICatalog{
    id: number;
    count:number;
    name: string;
    shortDescription:string;
    price?:number;
    time?:string;
    countPerson?:number;
    category?:string;
    howHappen?:string;
    whySelect?:string;
    url?:string;
    adress?:string;
    images?:Array<string>;
    size?:string;
    city?:string;
    map?:string;
}
