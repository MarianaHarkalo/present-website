import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { IFedback } from '../interfaces/fedback.interface';

@Injectable({
  providedIn: 'root'
})
export class FedbackService {
  private url: string;
  constructor(private http: HttpClient) { 
    this.url = 'http://localhost:3000/fedback';
  }
  getFedback(): Observable<Array<IFedback>> {
    return this.http.get<Array<IFedback>>(this.url);
  }

  addFedback(fedback: IFedback): Observable<Array<IFedback>> {
    return this.http.post<Array<IFedback>>(this.url, fedback);
  }
  deleteFedback(fedback: IFedback): Observable<Array<IFedback>> {
    return this.http.delete<Array<IFedback>>(`${this.url}/${fedback.id}`);
  }
  updateFedback(fedback: IFedback): Observable<Array<IFedback>> {
    return this.http.put<Array<IFedback>>(`${this.url}/${fedback.id}`, fedback);
  }
}
