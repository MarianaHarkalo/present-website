import { TestBed } from '@angular/core/testing';

import { FedbackService } from './fedback.service';

describe('FedbackService', () => {
  let service: FedbackService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FedbackService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
