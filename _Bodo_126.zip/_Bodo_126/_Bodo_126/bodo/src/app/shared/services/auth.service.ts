import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import 'firebase/firestore';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentUser: any;
  userStatus: string;
  userChecker: boolean;

  constructor(private afAuth: AngularFireAuth,
    private firestore: AngularFirestore,
    private router: Router) { }
  login(email: string, password: string) {
    if(email=="admin@gmail.com"||password=="123456"){
      this.userChecker = true;
      this.router.navigate(["/admin"]);
    }
  
  }
  isLogin(): boolean {
    return this.userChecker;
  }
}
