import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICatalog } from '../interfaces/catalog.interface';
@Injectable({
  providedIn: 'root'
})
export class CatalogService {

  private url: string;
  constructor(private http: HttpClient) {
    this.url = 'http://localhost:3000/catalog';
  }

  getCatalog(): Observable<Array<ICatalog>> {
    return this.http.get<Array<ICatalog>>(this.url);
  }

  addCatalog(catalog: ICatalog): Observable<Array<ICatalog>> {
    return this.http.post<Array<ICatalog>>(this.url, catalog);
  }

  deleteCatalog(catalog: ICatalog): Observable<Array<ICatalog>> {
    return this.http.delete<Array<ICatalog>>(`${this.url}/${catalog.id}`);
  }

  updateCatalog(catalog: ICatalog): Observable<Array<ICatalog>> {
    return this.http.put<Array<ICatalog>>(`${this.url}/${catalog.id}`, catalog);
}
getOneCatalog(id: number): Observable<ICatalog> {
  return this.http.get<ICatalog>(`${this.url}/${id}`)
}
}