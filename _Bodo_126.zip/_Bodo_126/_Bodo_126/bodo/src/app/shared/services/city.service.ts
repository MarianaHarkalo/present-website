import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ICity } from '../interfaces/city.interface';
import { Observable } from 'rxjs';
import { ICategory } from '../interfaces/category.interface';

@Injectable({
  providedIn: 'root'
})
export class CityService {

  
  private url: string;
  constructor(private http: HttpClient) {
    this.url = 'http://localhost:3000/city';
  }

  getCategory(): Observable<Array<ICity>> {
    return this.http.get<Array<ICity>>(this.url);
  }

  addCategory(category: ICity): Observable<Array<ICity>> {
    return this.http.post<Array<ICity>>(this.url, category);
  }

  deleteCategory(category: ICity): Observable<Array<ICity>> {
    return this.http.delete<Array<ICity>>(`${this.url}/${category.id}`);
  }

  updateCategory(category: ICity): Observable<Array<ICity>> {
    return this.http.put<Array<ICity>>(`${this.url}/${category.id}`, category);
  }
}
