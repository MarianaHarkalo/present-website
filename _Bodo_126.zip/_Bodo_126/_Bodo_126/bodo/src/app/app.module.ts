import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatSliderModule } from '@angular/material/slider';
import {MatPaginatorModule} from '@angular/material/paginator'

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';



import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';


import { HomePresentComponent } from './pages/PRESENT/homePresent/home.component';
import { CatalogComponent } from './pages/PRESENT/catalog/catalog.component';
import { DeliveryComponent } from './pages/PRESENT/delivery/delivery.component';
import { AboutUSComponent } from './pages/PRESENT/about-us/about-us.component';
import { FeedbackPresentsComponent } from './pages/PRESENT/feedback-presents/feedback-presents.component';
import { HowItWorkComponent } from './pages/PRESENT/how-it-work/how-it-work.component';
import { BasketComponent } from './pages/PRESENT/basket/basket.component';

import { AdminComponent } from './pages/admin/admin.component';


import { NgxUiLoaderModule, NgxUiLoaderRouterModule, NgxUiLoaderHttpModule } from 'ngx-ui-loader';
import { ngxUiLoaderConfig } from './preloader-config';
import { AdminCatalogComponent } from './pages/admin/admin-catalog/admin-catalog.component';
import { AdminCategoriesComponent } from './pages/admin/admin-categories/admin-categories.component';



import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { environment } from '../environments/environment';
import { CatalogDetailsComponent } from './pages/PRESENT/catalog-details/catalog-details.component';


import { ModalModule } from 'ngx-bootstrap/modal';
import { FilterPipe } from './shared/pipes/filter.pipe';

import {NgxPaginationModule} from 'ngx-pagination'; 
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { NgpSortModule } from "ngp-sort-pipe";

import {MatSelectModule} from '@angular/material/select';
import { SavePipe } from './shared/pipes/save.pipe';
import { GoogleMapsModule } from '@angular/google-maps';
import { AdminCityComponent } from './pages/admin/admin-city/admin-city.component';
import { LoginComponent } from './pages/login/login.component';
import { AdminFedbackComponent } from './pages/admin/admin-fedback/admin-fedback.component';
import { AdminOrderComponent } from './pages/admin/admin-order/admin-order.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomePresentComponent,
    CatalogComponent,
    DeliveryComponent,
    FeedbackPresentsComponent,
    AboutUSComponent,
    AdminComponent,
    HowItWorkComponent,
    BasketComponent,
    AdminCatalogComponent,
    AdminCategoriesComponent,
    CatalogDetailsComponent,
    FilterPipe,
    SavePipe,
    AdminCityComponent,
    LoginComponent,
    AdminFedbackComponent,
    AdminOrderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    GoogleMapsModule,
    // SliderModule,
    FormsModule,
    ReactiveFormsModule ,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderRouterModule,
   HttpClientModule,
   AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    ModalModule,
    NgxPaginationModule,
    SlickCarouselModule ,
    CarouselModule.forRoot(),
    MatSelectModule,
    NgpSortModule,
    MatSliderModule,
    MatPaginatorModule,
 

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
