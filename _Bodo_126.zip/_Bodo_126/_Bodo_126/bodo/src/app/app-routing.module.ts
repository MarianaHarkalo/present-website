import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomePresentComponent } from './pages/PRESENT/homePresent/home.component';
import { CatalogComponent } from './pages/PRESENT/catalog/catalog.component';
import { DeliveryComponent } from './pages/PRESENT/delivery/delivery.component';
import { AboutUSComponent } from './pages/PRESENT/about-us/about-us.component';
import { FeedbackPresentsComponent } from './pages/PRESENT/feedback-presents/feedback-presents.component';
import { HowItWorkComponent } from './pages/PRESENT/how-it-work/how-it-work.component';
import { BasketComponent } from './pages/PRESENT/basket/basket.component';
import { CatalogDetailsComponent } from './pages/PRESENT/catalog-details/catalog-details.component';


import { AdminCategoriesComponent } from './pages/admin/admin-categories/admin-categories.component';
import { AdminComponent } from './pages/admin/admin.component';
import { AdminCatalogComponent } from './pages/admin/admin-catalog/admin-catalog.component';
import { AdminCityComponent } from './pages/admin/admin-city/admin-city.component'
import { AdminFedbackComponent } from './pages/admin/admin-fedback/admin-fedback.component';
import { AdminOrderComponent } from './pages/admin/admin-order/admin-order.component';


import { LoginComponent } from './pages/login/login.component';
import { AuthGuard } from './shared/guards/auth.guard';
const routes: Routes = [

  { path: '', pathMatch: 'full', redirectTo: 'homePresent' },
    { path: '', pathMatch: 'full', redirectTo: 'homePresent' },
    {path:'homePresent',component:HomePresentComponent},
    {path:'catalog',component:CatalogComponent},
    {path:'catalog/:id', component: CatalogDetailsComponent },
    {path:'basket/catalog/:id', component: CatalogDetailsComponent },
    {path:'delivery',component:DeliveryComponent},
    {path:'delivery',component:DeliveryComponent},
    {path:'aboutUS',component:AboutUSComponent},
    {path:'feedbackPresent',component:FeedbackPresentsComponent},
    {path:'howItWork',component:HowItWorkComponent},
    {path:'basket',component:BasketComponent},
    { path: 'admin', canActivate:[AuthGuard], component: AdminComponent, children: [
    { path: '', pathMatch: 'full', redirectTo: 'adminCatalog' },
    {path:'adminCatalog',component: AdminCatalogComponent },
    {path:'adminCategories',component: AdminCategoriesComponent },
    {path:'adminCity',component: AdminCityComponent },
    {path:'adminFedback',component: AdminFedbackComponent },
    {path:'adminOrder',component: AdminOrderComponent },
  ]},
  {path:'login',component: LoginComponent },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
