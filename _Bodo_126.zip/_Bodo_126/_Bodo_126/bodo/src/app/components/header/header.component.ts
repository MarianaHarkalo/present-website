import { Component, OnInit } from '@angular/core';
import { ICatalog } from 'src/app/shared/interfaces/catalog.interface';
import { OrdersService } from 'src/app/shared/services/orders.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  totalPrice = 0;
  getCatalog: Array<ICatalog> = [];
  constructor(private orderService: OrdersService) { }

  ngOnInit(): void {
    this.getLocalStorage()
    this.productLength()
   console.log(this.productLength());
  }
  private productLength(): void {
    this.orderService.basket.subscribe(
      () => {
        this.getLocalStorage();
      }
    );
  }
  private getLocalStorage(): void {
    if (localStorage.length > 0 && localStorage.getItem('catalog')) {
      this.getCatalog = JSON.parse(localStorage.getItem('catalog'));
      this.totalPrice = this.getCatalog.reduce((total, elem) => {
        return total +  elem.count;
      }, 0);
    }
  }
}
